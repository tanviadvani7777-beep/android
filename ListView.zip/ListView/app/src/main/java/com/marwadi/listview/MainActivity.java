package com.marwadi.listview;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView list;
    ArrayList <String> arrayList;
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        list = findViewById(R.id.listview);

    //Adding data to Arraylist.
            arrayList = new ArrayList<>();
            arrayList.add("Mango");
            arrayList.add("Banana");
            arrayList.add("Orange");
            arrayList.add("Guava");
            arrayList.add("Grapes");
            arrayList.add("pineapple");
            arrayList.add("apple ");
            arrayList.add("Watermelon");

        arrayList.add("Mango");
        arrayList.add("Banana");
        arrayList.add("Orange");
        arrayList.add("Guava");
        arrayList.add("Grapes");
        arrayList.add("pineapple");
        arrayList.add("apple ");
        arrayList.add("Watermelon");


                //setting data to a adapter.
        arrayAdapter= new ArrayAdapter<>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                arrayList
                );
//Filling List with Adapterdata came from Arraylist .
        list.setAdapter(arrayAdapter);


    }
}