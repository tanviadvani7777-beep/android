package com.example.timepicker;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.TimePicker;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TimePicker timePicker;
    TextView textViewSelectedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timePicker = findViewById(R.id.timePicker);
        textViewSelectedTime = findViewById(R.id.textViewSelectedTime);

        timePicker.setOnTimeChangedListener((view, hourOfDay, minute) -> {
            String time = String.format("%02d:%02d", hourOfDay, minute);
            textViewSelectedTime.setText("Selected Time: " + time);
        });
    }
}
