package com.marwadi.contentresolver;



import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnLoad;
    TextView txtContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLoad = findViewById(R.id.btnLoad);
        txtContacts = findViewById(R.id.txtContacts);

        btnLoad.setOnClickListener(v -> loadContacts());
    }

    private void loadContacts() {
        StringBuilder contactsData = new StringBuilder();

        // ✅ Define only required columns (Best Practice)
        String[] projection = {
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
        };

        Cursor cursor = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                null,
                null,
                null
        );

        if (cursor != null) {

            // ✅ Get column indexes safely
            int nameIndex = cursor.getColumnIndexOrThrow(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            );

            int phoneIndex = cursor.getColumnIndexOrThrow(
                    ContactsContract.CommonDataKinds.Phone.NUMBER
            );

            while (cursor.moveToNext()) {
                String name = cursor.getString(nameIndex);
                String phone = cursor.getString(phoneIndex);

                contactsData.append("Name: ")
                        .append(name)
                        .append("\nPhone: ")
                        .append(phone)
                        .append("\n\n");
            }

            cursor.close();
        }

        txtContacts.setText(contactsData.toString());
    }
}